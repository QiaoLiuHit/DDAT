from .transt import TransT

def get_tracker_class():
    return TransT