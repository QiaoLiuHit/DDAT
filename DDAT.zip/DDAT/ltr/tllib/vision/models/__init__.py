from .resnet import *
from .digits import *

__all__ = ['resnet', 'digits']
