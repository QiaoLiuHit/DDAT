from .rcnn import DecoupledGeneralizedRCNN
from .retinanet import DecoupledRetinaNet