from .roi_heads import DecoupledRes5ROIHeads
