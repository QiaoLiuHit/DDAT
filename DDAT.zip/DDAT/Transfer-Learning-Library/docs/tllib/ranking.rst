=====================
Ranking
=====================



.. _H_score:

H-score
-------------------------------------------

.. autofunction:: tllib.ranking.hscore.h_score


.. _LEEP:

LEEP: Log Expected Empirical Prediction
-------------------------------------------

.. autofunction:: tllib.ranking.leep.log_expected_empirical_prediction


.. _NCE:

NCE: Negative Conditional Entropy
-------------------------------------------

.. autofunction:: tllib.ranking.nce.negative_conditional_entropy


.. _LogME:

LogME: Log Maximum Evidence
-------------------------------------------

.. autofunction:: tllib.ranking.logme.log_maximum_evidence

